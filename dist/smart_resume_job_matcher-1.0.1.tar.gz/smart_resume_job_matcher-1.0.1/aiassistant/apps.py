from django.apps import AppConfig


class AiassistantConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'aiassistant'
